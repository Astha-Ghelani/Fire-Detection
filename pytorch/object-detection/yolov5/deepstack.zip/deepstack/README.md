## Deepstack
This folder contains training performed using https://github.com/johnolafenwa/deepstack-trainer

These models can be deployed directly to deepstack